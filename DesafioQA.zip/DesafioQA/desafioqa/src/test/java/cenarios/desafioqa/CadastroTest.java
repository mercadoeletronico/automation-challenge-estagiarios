package cenarios.desafioqa;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import classes.desafioqa.CadastroUsuario;

public class CadastroTest {

	private CadastroUsuario cadastro;

	@Before
	public void before() {
		this.cadastro = new CadastroUsuario();
	}

	@After
	public void after() {
		this.cadastro.fecharBrowser();
	}

	@Test
	public void realizaCadastro() throws InterruptedException {
		cadastro.preencheForm("lucas.roxo@me.com.br", "Masculino", "Me", "Contrata", "123456", "5", "April",
				"1995", "Rua A", "Cidade B", "Alabama", "01234", "912345678");
		
		cadastro.validaCadastro();
	}
	


}
