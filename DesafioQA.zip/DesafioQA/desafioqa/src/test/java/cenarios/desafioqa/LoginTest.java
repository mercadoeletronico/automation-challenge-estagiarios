package cenarios.desafioqa;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import classes.desafioqa.LoginUsuario;

public class LoginTest {

	private LoginUsuario login;

	@Before
	public void before() {
		this.login = new LoginUsuario();
	}

	@After
	public void after() {
		this.login.fecharBrowser();
	}

	@Test
	public void realizaLogin() throws InterruptedException {
		login.preencheForm("lucas.roxo@me.com.br", "123456");
		
	}

}
