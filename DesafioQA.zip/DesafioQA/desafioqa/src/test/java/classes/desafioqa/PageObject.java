package classes.desafioqa;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageObject {

	protected WebDriver browser;

	// cria inst�ncia do web driver para todos os Page Objects
	public PageObject(WebDriver browser) {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

		// se browser igual a null, abre-se uma nova guia, se n�o, aproveita-se a guia
		// aberta
		if (browser == null) {
			this.browser = new ChromeDriver();
		} else {
			this.browser = browser;
		}
	}

	// fecha browser
	public void fecharBrowser() {
		// this.browser.quit();
	}

}
