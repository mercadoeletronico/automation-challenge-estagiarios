package classes.desafioqa;

import java.awt.Component;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.junit.Assert;
import org.openqa.selenium.By;

public class CadastroUsuario extends PageObject {

	private static final String URL = "http://automationpractice.com/index.php";

	public CadastroUsuario() {
		super(null);
		this.browser.navigate().to(URL);
	}

	// preenche form
	public void preencheForm(String email, String sexo, String nome, String sobrenome, String senha, String diaNasc,
			String mesNasc, String anoNasc, String endereco, String cidade, String estado, String CEP, String telefone)
			throws InterruptedException {

		// preenche e-mail de cadastro
		browser.findElement(By.className("login")).click();
		browser.findElement(By.id("email_create")).sendKeys(email);
		browser.findElement(By.id("SubmitCreate")).click();
		browser.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

		// se "Masculino" selecionar Mr., se n�o, Mrs.
		if (sexo.equals("Masculino")) {
			browser.findElement(By.id("id_gender1")).click();
		} else {
			browser.findElement(By.id("id_gender2")).click();
		}

		// preenche informa��es de cadastro
		browser.findElement(By.id("customer_firstname")).sendKeys(nome);
		browser.findElement(By.id("customer_lastname")).sendKeys(sobrenome);
		browser.findElement(By.id("passwd")).sendKeys(senha);
		browser.findElement(By.id("days")).sendKeys(diaNasc);
		browser.findElement(By.id("months")).sendKeys(mesNasc);
		browser.findElement(By.id("years")).sendKeys(anoNasc);
		browser.findElement(By.id("newsletter")).click();
		browser.findElement(By.id("optin")).click();
		browser.findElement(By.id("address1")).sendKeys(endereco);
		browser.findElement(By.id("city")).sendKeys(cidade);
		browser.findElement(By.id("id_state")).sendKeys(estado);
		browser.findElement(By.id("postcode")).sendKeys(CEP);
		browser.findElement(By.id("phone_mobile")).sendKeys(telefone);

		// submete form
		browser.findElement(By.id("submitAccount")).click();
		// Object frame = null;
		// JOptionPane.showMessageDialog((Component) frame, "Cadastro Efetuado");
	}

	public void validaCadastro() {
		Assert.assertTrue(
				browser.getCurrentUrl().equals("http://automationpractice.com/index.php?controller=my-account"));
		Object frame = null;
		JOptionPane.showMessageDialog((Component) frame, "Cadastro Efetuado");

	}

}
