package classes.desafioqa;

import java.awt.Component;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.junit.Assert;
import org.openqa.selenium.By;

public class LoginUsuario extends PageObject {

	private static final String URL = "http://automationpractice.com/index.php";

	public LoginUsuario() {
		super(null);
		this.browser.navigate().to(URL);
	}

	public void preencheForm(String email, String senha) throws InterruptedException {
		browser.findElement(By.className("login")).click();
		browser.findElement(By.id("email")).sendKeys(email);
		browser.findElement(By.id("passwd")).sendKeys(senha);
		browser.findElement(By.id("SubmitLogin")).click();
	}

	public void validaCadastro() {
		Assert.assertTrue(
				browser.getCurrentUrl().equals("http://automationpractice.com/index.php?controller=my-account"));
		Object frame = null;
		JOptionPane.showMessageDialog((Component) frame, "Login Efetuado");
	}
}
